# Bank Logos

A list of bank logos in `svg` format along with their associated colors, codes, official names, and nice names.

## Usage

You could use the `svg` file and the bank brand color (available in the `json` file) to do something as follows:

![Sample](https://raw.githubusercontent.com/omise/banks-logo/master/th/sample.png)

All bank icons are trademarks of their respective owners and the use of these trademarks does not indicate endorsement of the trademark holder by Opn Payments, nor vice versa.


